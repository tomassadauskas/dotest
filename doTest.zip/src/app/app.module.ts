import { ChucknorrisService } from './services/chucknorris.service';

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { ChucknorrisComponent } from './chucknorris/chucknorris.component';

import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    ChucknorrisComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule
  ],
  providers: [
    ChucknorrisService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
