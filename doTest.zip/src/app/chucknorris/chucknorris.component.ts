import { Component, OnInit } from '@angular/core';
import { ChucknorrisService } from '../services/chucknorris.service';


@Component({
  selector: 'app-chucknorris',
  templateUrl: './chucknorris.component.html',
  styleUrls: ['./chucknorris.component.css']
})
export class ChucknorrisComponent implements OnInit {
  inProgress: boolean;

fact: any;
categories: any;
category: string;

// search
searchInProgress: boolean;
query: string;
searchResults: any[];

  constructor(private srv: ChucknorrisService) {
   }

  ngOnInit() {
    this.inProgress = false;
    this.category = '';

    this.query = '';

    this.srv.getResource('random')
    .subscribe(rez => this.fact = rez);

    this.srv.getResource('categories')
    .subscribe(rez => this.categories = rez);
  }

  getWisdom() {
    this.inProgress = true;
    this.srv.getWisdom(this.category)
    .subscribe(rez => {
      this.fact = rez;
      this.inProgress = false;
    });
  }

  changeCat(value) {
    this.category = value;
    this.getWisdom();
  }

  runFilter() {
    if (this.query.length >= 3) {
      console.log('Value query: ', this.query);

      this.searchInProgress = true;
      this.srv.getList(this.query)
      .subscribe(rez => {
        this.searchResults = rez;
        this.searchInProgress = false;

        console.log('results: ', rez);
      });
    }
  }
}
