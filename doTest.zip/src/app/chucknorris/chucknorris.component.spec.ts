import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChucknorrisComponent } from './chucknorris.component';

describe('ChucknorrisComponent', () => {
  let component: ChucknorrisComponent;
  let fixture: ComponentFixture<ChucknorrisComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChucknorrisComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChucknorrisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
